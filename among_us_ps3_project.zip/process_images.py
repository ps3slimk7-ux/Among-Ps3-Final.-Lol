from PIL import Image
import os

def resize_image(input_path, output_path, size):
    try:
        with Image.open(input_path) as img:
            img = img.resize(size, Image.Resampling.LANCZOS)
            img.save(output_path)
            print(f"Resized {input_path} to {size} and saved to {output_path}")
    except Exception as e:
        print(f"Error processing {input_path}: {e}")

# PS3 Standard Sizes
# ICON0.PNG: 320x176
# PIC1.PNG: 1920x1080 (or 1280x720)

base_dir = "/home/ubuntu/among_us_ps3"
resize_image(os.path.join(base_dir, "ICON0.png"), os.path.join(base_dir, "ICON0.png"), (320, 176))
resize_image(os.path.join(base_dir, "PIC1.png"), os.path.join(base_dir, "PIC1.png"), (1280, 720))
