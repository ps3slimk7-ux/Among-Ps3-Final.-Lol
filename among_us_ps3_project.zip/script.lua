-- Among Us PS3 Clone (Local Multiplayer)
-- Basic Script for LuaPlayer PS3

-- Colors
WHITE = Color.new(255, 255, 255)
RED = Color.new(255, 0, 0)
BLUE = Color.new(0, 0, 255)
GREEN = Color.new(0, 255, 0)
BLACK = Color.new(0, 0, 0)

-- Game State
STATE_MENU = 0
STATE_GAME = 1
gameState = STATE_MENU

-- Players
players = {}
players[1] = { x = 100, y = 100, color = RED, name = "Player 1" }
players[2] = { x = 150, y = 100, color = BLUE, name = "Player 2" }

-- Map (The Skeld Simplified)
map_x = 0
map_y = 0

-- Main Loop
while true do
    screen:clear(BLACK)
    pad = Controls.read()

    if gameState == STATE_MENU then
        screen:print(200, 100, "Among Us PS3 Clone", WHITE)
        screen:print(200, 150, "Press START to Play", WHITE)
        
        if pad:start() then
            gameState = STATE_GAME
        end
    elseif gameState == STATE_GAME then
        -- Player 1 Movement (D-Pad)
        if pad:up() then players[1].y = players[1].y - 2 end
        if pad:down() then players[1].y = players[1].y + 2 end
        if pad:left() then players[1].x = players[1].x - 2 end
        if pad:right() then players[1].x = players[1].x + 2 end

        -- Draw Players (Simple Rectangles for now)
        for i=1, 2 do
            screen:fillRect(players[i].x, players[i].y, 20, 30, players[i].color)
            screen:print(players[i].x, players[i].y - 15, players[i].name, WHITE)
        end

        screen:print(10, 10, "Use D-Pad to Move P1", WHITE)
        screen:print(10, 30, "Press SELECT to Menu", WHITE)

        if pad:select() then
            gameState = STATE_MENU
        end
    end

    screen:flip()
    -- Wait for Vblank to prevent flickering
    screen.waitVblankStart()
end
